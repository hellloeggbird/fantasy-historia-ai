const ALLOWED_ORIGIN = "https://hellloeggbird.github.io";

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin");
    const corsHeaders = {
      "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Vary": "Origin"
    };
    const json = (data, status = 200) =>
      Response.json(data, { status, headers: corsHeaders });

    if (origin && origin !== ALLOWED_ORIGIN) return json({ error: "Origin not allowed" }, 403);
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders });

    const url = new URL(request.url);
    if (url.pathname !== "/api/ai") return json({ error: "Not found" }, 404);
    if (request.method !== "POST") return json({ error: "Use POST" }, 405);
    if (!env.GEMINI_API_KEY) return json({ error: "GEMINI_API_KEY secret is not configured" }, 500);

    const length = Number(request.headers.get("Content-Length") || 0);
    if (length > 20000) return json({ error: "Request too large" }, 413);

    try {
      const body = await request.json();
      if (typeof body.prompt !== "string" || !body.prompt.trim() || body.prompt.length > 10000)
        return json({ error: "Provide a prompt up to 10000 characters" }, 400);

      const context = JSON.stringify(body.context ?? {});
      if (context.length > 8000) return json({ error: "Game context too large" }, 413);

      const upstream = await fetch(
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
        {
          method: "POST",
          headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
          body: JSON.stringify({
            systemInstruction: { parts: [{ text: "You are the AI game master for Fantasy Historia, a fantasy world simulation. Generate imaginative, coherent kingdoms, characters, diplomacy, events, and consequences. Respect the supplied game state. Be concise and useful." }] },
            contents: [{ role: "user", parts: [{ text: "Game context:\n" + context + "\n\nRequest:\n" + body.prompt }] }]
          })
        }
      );
      const result = await upstream.json();
      if (!upstream.ok) return json({ error: "Gemini request failed", details: result.error?.message || "Check the model and API quota" }, upstream.status === 429 ? 429 : 502);
      const text = result.candidates?.[0]?.content?.parts?.map(part => part.text || "").join("");
      if (!text) return json({ error: "Gemini returned no text" }, 502);
      return json({ text });
    } catch {
      return json({ error: "Invalid request or AI service unavailable" }, 400);
    }
  }
};
