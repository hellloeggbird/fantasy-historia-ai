Fantasy Historia Gemini Worker

Do not put your Gemini API key in these files or commit it to GitHub.
In Cloudflare Worker Settings, add a Secret named GEMINI_API_KEY with your key.
Allowed website origin: https://hellloeggbird.github.io
Endpoint: POST /api/ai

This is Worker source code, not a static website. If Deployments only accepts a Git repository, upload these files to a separate GitHub repository and connect it to Workers & Pages. If Cloudflare offers an editor, paste src/index.js into it instead.
